# Changelog

## 2025-08-26 — Final v3
- Self‑contained `update-binary` (no edify / unzip required).
- Writes to flash‑mounted partitions to persist changes.
- Adds `pmf=0` and `disable_pmksa_caching=1` to Wi‑Fi config.
- Repairs SELinux context & permissions for Wi‑Fi config and `dhcpcd`.
