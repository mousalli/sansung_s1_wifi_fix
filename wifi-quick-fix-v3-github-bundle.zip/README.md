# Wi‑Fi Quick Fix v3 (TWRP) — Broadcom / Legacy ROMs

This TWRP‑flashable package fixes **instant Wi‑Fi disconnect loops** on legacy Broadcom devices (e.g. Galaxy S / bcmdhd) by disabling PMF/IGTK and repairing Wi‑Fi/DHCP permissions.

## What it fixes
- `WPA: Failed to configure IGTK` / immediate disconnect after connect
- Ensures `wpa_supplicant.conf` has:
  ```
  pmf=0
  disable_pmksa_caching=1
  ```
- Restores typical ownership/SELinux context on `/data/misc/wifi/wpa_supplicant.conf`
- Best‑effort permission/context repair for `/system/bin/dhcpcd`

## Download
- **Release ZIP:** `WiFi_Quick_Fix_TWRP_FINAL.zip` (in [/releases](./releases))  
  SHA‑256: `36a7b787f6dd8bfafe3a1b9f2b8507b039be476a35151673c4a8d17037d6dac3`

## How to flash
1. Copy the ZIP to **/sdcard** (internal storage).
2. Boot **TWRP** → **Mount**: check **System** and **Data**.
3. **Install** the ZIP → Reboot.

> Note: If TWRP shows “zip is corrupted”, disable *Zip signature verification* in TWRP Settings and install from Internal Storage (avoid sideload for non‑OTA zips).

## Tested on
- Samsung **GT‑I9000** (Galaxy S) — OmniROM Marshmallow
- **bcmdhd** Wi‑Fi driver
- TWRP 3.0.x

## How it works
The ZIP contains only a self‑contained `update-binary` that writes the needed files **directly to flash‑mounted partitions** (no edify needed). Config backups are created with a timestamp.

## Contributing
Issues and PRs welcome. Please attach `logcat`, `dmesg`, and `recovery.log` when reporting.

## License
MIT
